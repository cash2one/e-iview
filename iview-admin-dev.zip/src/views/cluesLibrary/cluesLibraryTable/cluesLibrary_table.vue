<style lang="less">
    .vertical-center-modal {
        display: flex;
        align-items: center;
        justify-content: center;

        .ivu-modal {
            top: 0;
        }
    }
</style>
<template>
    <div>
        <Card>
            <Row>
                <ButtonGroup>
                    <Button type="primary" icon="ios-color-wand-outline" @click="modal2 = true">新增线索</Button>
                    <Button type="primary" icon="ios-color-wand-outline" @click="EditClues">编辑</Button>
                </ButtonGroup>
            </Row>
            <Row style="margin-top: 10px;">
                <Table
                        highlight-row
                        size="small"
                        :columns="columns"
                        :data="data2"
                        @on-current-change="selectRow"></Table>
                <Page
                        size="small"
                        :total="pageTotal"
                        show-total
                        show-sizer
                        show-elevator
                        @on-change="pageChange"
                        @on-page-size-change="pageSizeChange"
                        style="margin-top: 10px"></Page>
            </Row>
        </Card>
        <Modal
                v-model="modal2"
                title="新增线索"
                class-name="vertical-center-modal"
                ok-text="保存"
                :styles="{top: '10%'}"
                :loading="loading"
                @on-ok="ok22('formValidate')"
                @on-cancel="cancel('formValidate')">
            <Form ref="formValidate" :model="formValidate"  :rules="ruleValidate" :label-width="70">
                <FormItem label="公司名" prop="companyid">
                    <Select v-model="formValidate.companyid" filterable>
                        <Option v-for="item in companynameValue" :value="item.value" :key="item.value">{{ item.label
                            }}
                        </Option>
                    </Select>
                </FormItem>
                <FormItem label="线索类型" prop="cluestype">
                    <Select v-model="formValidate.cluestype" filterable>
                        <Option v-for="item in cluesTypeValue" :value="item.value" :key="item.value">{{ item.label
                            }}
                        </Option>
                    </Select>
                </FormItem>
                <FormItem label="线索标签" prop="labels">
                    <Tag v-for="item in customerlabelGroup" :key="item" :name="item" :id="item.id" closable
                         @on-close="handleClose2">
                        {{ item.labelName }}
                    </Tag>
                    <Button icon="ios-plus-empty" type="dashed" size="small" @click="getLabelData();addTag = true">添加</Button>
                </FormItem>
                <FormItem label="线索说明" prop="cluescontent">
                    <Input v-model="formValidate.cluescontent" type="textarea" :autosize="{minRows: 2,maxRows: 5}"></Input>
                </FormItem>
            </Form>
        </Modal>
        <Modal
                v-model="modal3"
                title="编辑线索"
                class-name="vertical-center-modal"
                ok-text="保存"
                :styles="{top: '10%'}"
                :loading="loading"
                @on-ok="ok('formValidate2')"
                @on-cancel="cancel('formValidate2')">
            <Form ref="formValidate2" :model="formValidate2" :label-width="70">
                <FormItem label="公司名称" prop="companyname">
                    <Input v-model="formValidate2.companyname" disabled></Input>
                </FormItem>
                <FormItem label="客户名称" prop="customername">
                    <Input v-model="formValidate2.customername" disabled></Input>
                </FormItem>
                <FormItem label="客户电话" prop="tel">
                    <Input v-model="formValidate2.tel" disabled></Input>
                </FormItem>
                <FormItem label="线索状态" prop="cluesstatus">
                    <Input v-model="formValidate2.cluesstatus" disabled></Input>
                </FormItem>
                <FormItem label="线索类型" prop="cluestype">
                    <Input v-model="formValidate2.cluestype" disabled></Input>
                </FormItem>
                <FormItem label="创建人" prop="createby">
                    <Input v-model="formValidate2.createby" disabled></Input>
                </FormItem>
                <FormItem label="创建时间" prop="createdate">
                    <Input v-model="formValidate2.createdate" disabled></Input>
                </FormItem>
                <FormItem label="线索标签" prop="labelName">
                    <Tag v-for="item in customerlabelGroup" :key="item" :name="item" :id="item.id" closable
                         @on-close="handleClose2">
                        {{ item.labelName }}
                    </Tag>
                    <Button icon="ios-plus-empty" type="dashed" size="small" @click="getLabelData();addTag = true">添加</Button>
                </FormItem>
                <FormItem label="线索说明" prop="cluescontent">
                    <Input v-model="formValidate2.cluescontent" type="textarea"
                           :autosize="{minRows: 2,maxRows: 5}"></Input>
                </FormItem>
            </Form>
        </Modal>
        <Modal
                v-model="addTag"
                title="添加标签"
                @on-ok="ok2"
                @on-cancel="cancel2">
            <Table
                    border
                    ref="selection"
                    :columns="columns4"
                    :data="data"
                    @on-selection-change="selectionChange"></Table>
            <Page
                    size="small"
                    :total="pageTotal2"
                    show-total
                    show-sizer
                    show-elevator
                    @on-change="pageChange2"
                    @on-page-size-change="pageSizeChange2"
                    style="margin-top: 10px"></Page>
        </Modal>
    </div>
</template>

<script>

    export default {
        data() {
            return {
                addTag: false,
                isEidt: false,
                modal1: false,
                modal2: false,
                modal3: false,
                companynameValue: [],
                cluesTypeValue: [],
                ruleValidate: {
                    companyid: [
                        { required: true, message: '请选择公司'}
                    ],
                    cluestype: [
                        { required: true, message: '请选择线索类型', trigger: 'change' }
                    ],
                    cluescontent: [
                        { required: true, message: '请填写线索说明', trigger: 'blur' },
                    ]
                },
                formValidate: {
                    lables: '',
                    companyid: '',
                    cluestype: '',
                    cluescontent: '',
                },
                formValidate2: {
                    cluescontent: '',
                    cluestype: '',
                    cluesstatus: '',
                    companyid: '',
                    companyname: '',
                    createby: '',
                    customername: '',
                    id: '',
                    label: '',
                    receiveby: '',
                    tel: '',
                    createdate: ''
                },
                columns: [
                    {
                        title: '公司名称',
                        key: 'companyname'
                    },
                    {
                        title: '客户名称',
                        key: 'customername'
                    },
                    {
                        title: '客户手机号',
                        key: 'tel'
                    },
                    {
                        title: '线索状态',
                        key: 'cluesstatus'
                    },
                    {
                        title: '线索创建时间',
                        key: 'createdate'
                    },
                    {
                        title: '创建人',
                        key: 'createby'
                    },
                    {
                        title: '领取人',
                        key: 'receiveby'
                    },
                    {
                        title: '线索标签',
                        key: 'labelName'
                    },
                    {
                        title: '线索类型',
                        key: 'cluestype'
                    },
                    {
                        title: '线索详情',
                        key: 'cluescontent'
                    },
                ],
                columns4: [
                    {
                        type: 'selection',
                        width: 60,
                        align: 'center'
                    },
                    {
                        title: '标签',
                        key: 'labelName'
                    },
                ],
                data: [],
                data1: [],
                data2: [],
                customerlabelGroup: [],
                cluesid: '',
                pageTotal: '',
                pageTotal2: '',
                pageSize: 10,
                customerid: ''
            }
        },
        methods: {
            // 表格数据请求
            getTableData() {
                let _self = this
                let url = '/cluesLibrary/findAllByPages/1/10'

                _self.data2 = []

                function doSuccess(response) {
                    _self.pageTotal = response.data.data.total

                    for (let i = 0; i < response.data.data.rows.length; i++) {
                        _self.data2.push({
                            id: response.data.data.rows[i].id,
                            cluestype: response.data.data.rows[i].cluestype,
                            cluescontent: response.data.data.rows[i].cluescontent,
                            cluesstatus: response.data.data.rows[i].cluesstatus,
                            companyname: response.data.data.rows[i].companyname,
                            tel: response.data.data.rows[i].tel,
                            createby: response.data.data.rows[i].createby,
                            customername: response.data.data.rows[i].customername,
                            labelName: response.data.data.rows[i].labelName,
                            receiveby: response.data.data.rows[i].receiveby,
                            createdate: response.data.data.rows[i].createdate,
                        })
                    }
                }

                this.GetData(url, doSuccess)
            },

            // 改变页码
            pageChange(a) {
                let _self = this
                let url = '/order/queryListByChannel?page=' + a + '&pageSize=' + _self.pageSize

                _self.data2 = []

                function doSuccess(response) {
                    _self.pageTotal = response.data.data.total

                    for (let i = 0; i < response.data.data.rows.length; i++) {
                        _self.data2.push({
                            id: response.data.data.rows[i].id,
                            cluescontent: response.data.data.rows[i].cluescontent,
                            cluesstatus: response.data.data.rows[i].cluesstatus,
                            companyname: response.data.data.rows[i].companyname,
                            tel: response.data.data.rows[i].tel,
                            createby: response.data.data.rows[i].createby,
                            customername: response.data.data.rows[i].customername,
                            labelName: response.data.data.rows[i].labelName,
                            receiveby: response.data.data.rows[i].receiveby,
                        })
                    }
                }

                this.GetData(url, doSuccess)
            },

            // 改变每页显示的数据条数
            pageSizeChange(a) {
                let _self = this
                let url = '/order/queryListByChannel?page=1&pageSize=' + a
                _self.pageSize = a
                _self.data2 = []

                function doSuccess(response) {
                    _self.pageTotal = response.data.data.total

                    for (let i = 0; i < response.data.data.rows.length; i++) {
                        _self.data2.push({
                            id: response.data.data.rows[i].id,
                            cluescontent: response.data.data.rows[i].cluescontent,
                            cluesstatus: response.data.data.rows[i].cluesstatus,
                            companyname: response.data.data.rows[i].companyname,
                            tel: response.data.data.rows[i].tel,
                            createby: response.data.data.rows[i].createby,
                            customername: response.data.data.rows[i].customername,
                            labelName: response.data.data.rows[i].labelName,
                            receiveby: response.data.data.rows[i].receiveby,
                        })
                    }
                }

                this.GetData(url, doSuccess)
            },

            // 表格行选中事件
            selectRow(a) {
                var _self = this
                _self.cluesid = a.id
            },

            detail(e) {
                let _self = this
                let url = '/order/queryListByCustomer?customerId=' + e.row.oacustomerid + '&page=1&pageSize=10000'

                _self.modal2 = true
                _self.formValidate.companyname = e.row.companyname
                _self.formValidate.name = e.row.name
                _self.formValidate.tel = e.row.tel
                _self.formValidate.updatedate = e.row.updatedate
                _self.formValidate.createby = e.row.createby
                _self.formValidate.realnumber = e.row.realnumber

                function doSuccess(response) {
                    let _rowsData = response.data.data.rows
                    for (let i = 0; i < _rowsData.length; i++) {
                        let url2 = '/order/detail/' + _rowsData[i].id

                        function doSuccess2(response) {
                            let _data = response.data.data.items

                            for (let i = 0; i < _data.length; i++) {
                                _self.data1.push({
                                    product: _data[i].product,
                                    propertys: _data[i].propertys,
                                    productnumber: _data[i].productnumber,
                                    paynumber: _data[i].paynumber,
                                })
                            }
                        }

                        _self.GetData(url2, doSuccess2)
                    }
                }

                this.GetData(url, doSuccess)
            },

            EditClues() {
                let _self = this
                let url = '/cluesLibrary/findCluesLibraryById/' + _self.cluesid
                _self.modal3 = true
                let a = []

                function doSuccess(response) {
                    let _res = response.data.data
                    _self.customerlabelGroup = []
                    _self.formValidate2.cluescontent = _res.cluescontent
                    _self.formValidate2.cluestype = _res.cluestype
                    _self.formValidate2.id = _res.id
                    _self.formValidate2.cluesstatus = _res.cluesstatus
                    _self.formValidate2.companyid = _res.companyid
                    _self.formValidate2.companyname = _res.companyname
                    _self.formValidate2.createby = _res.createby
                    _self.formValidate2.customername = _res.customername
                    _self.formValidate2.labelName = _res.labelName
                    _self.formValidate2.tel = _res.tel
                    _self.formValidate2.createdate = _res.createdate
//                    _self.customerlabelGroup = _res.labelName.split(",");

                    if(_res.labelName != null) {
                        a = _res.labelName.split(",")
                        for (let i = 0; i < a.length; i++) {
                            let b = {}
                            b.labelName = a[i]
                            _self.customerlabelGroup.push(b)
                        }
                        _self.getLabelData()
                    } else {
                        _self.customerlabelGroup = []
                    }
                }

                this.GetData(url, doSuccess)
            },

            getLabelData() {
                var _self = this
                _self.data = []
                this.$http.get('/api/label/findAllLabelByPages/1/10')
                    .then(function (data) {
                        var response = data.data.data
                        _self.pageTotal2 = response.total
                        let _customerlabelGroup = []
                        for (var i = 0; i < response.rows.length; i++) {
                            var reponseObj = {}
                            reponseObj.labelName = response.rows[i].labelName
                            reponseObj.id = response.rows[i].id
                            for (let i = 0; i < _self.customerlabelGroup.length; i++) {
                                if (reponseObj.labelName == _self.customerlabelGroup[i].labelName) {
                                    reponseObj._checked = true
                                    _customerlabelGroup.push(reponseObj)
                                }
                            }
                            _self.data.push(reponseObj)
                        }
//                        _self.customerlabelGroup = _customerlabelGroup
                    })
            },

            selectionChange(e) {
                let _self = this
                _self.customerlabelGroup = []

                for (let i = 0; i < e.length; i++) {
                    let _labels = {}
                    _labels.id = e[i].id
                    _labels.labelName = e[i].labelName
                    _self.customerlabelGroup.push(_labels)
                }
            },

            /*************************移除标签********************************/
            handleClose2(event, name) {
                let _self = this
                for (let i = 0; i < _self.customerlabelGroup.length; i++) {
                    if (_self.customerlabelGroup[i].labelName == name.labelName) {
                        let index = _self.customerlabelGroup.indexOf(name);
                        if (index > -1) {
                            _self.customerlabelGroup.splice(index, 1);
                        }
                    }
                }
            },

            /*************************录入提交验证********************************/
            ok(name) {
                let _self = this
                setTimeout(() => {
                    if (_self.customerlabelGroup != undefined) {
                        let labelIds = []
                        for (let i = 0; i < _self.customerlabelGroup.length; i++) {
                            labelIds.push(_self.customerlabelGroup[i].id)
                        }
                        _self.formValidate2.labels = labelIds.toString()
                    }

                    let url = '/cluesLibrary/updateCluesLibrary'
                    let _data = {}
                    _data.cluescontent = _self.formValidate2.cluescontent
                    _data.companyid = _self.formValidate2.companyid
                    _data.lables = _self.formValidate2.labels
                    _data.id = _self.formValidate2.id

                    function doSuccess(response) {
                        _self.$Message.success('更新成功!')
                        _self.getTableData()
                    }

                    this.PostData(url, _data, doSuccess)
                }, 2000);
            },

            AddClues() {
                let _self = this
                let url = '/cluesLibrary/loadCompany'

                function doSuccess(response) {
                    let _res = response.data.data

                    for (let i = 0; i < _res.length; i++) {

                        let issendObj = {}

                        issendObj.label = _res[i].CompanyName
                        issendObj.value = _res[i].companyId
                        _self.companynameValue.push(issendObj)
                    }
                }

                this.GetData(url, doSuccess)

                this.$http.get('/api/dataCenter/system/queryForTSTypeByGroupId/10339')
                    .then(function (response) {
                        let _res = response.data

                        for (let i = 0; i < _res.length; i++) {

                            let issendObj = {}

                            issendObj.label = _res[i].typename
                            issendObj.value = _res[i].typecode
                            _self.cluesTypeValue.push(issendObj)
                        }
                    })
            },

            /*************************录入提交验证********************************/
            ok22(name) {
                let _self = this
                setTimeout(() => {
                    if (_self.customerlabelGroup != undefined) {
                        let labelIds = []
                        for (let i = 0; i < _self.customerlabelGroup.length; i++) {
                            labelIds.push(_self.customerlabelGroup[i].id)
                        }
                        _self.formValidate.lables = labelIds.toString()
                    }

                    let url = '/cluesLibrary/saveCluesLibrary'

                    function doSuccess(response) {
                        _self.$Message.success('更新成功!')
                        _self.$refs['formValidate'].resetFields();
                        _self.getTableData()
                    }

                    this.PostData(url, _self.formValidate, doSuccess)
                }, 2000);
            },
        },
        mounted() {
            this.getTableData()
            this.AddClues()
        }
    }
</script>