<style>
    /*@import '../../../libs/easyUI/demo.css';*/
    @import '../../libs/easyUI/easyui.css';
    @import '../../libs/easyUI/icon.css';
</style>
<template>
    <div>
        <Modal
                v-model="orderAdd"
                title="录入"
                :width="1300"
                @on-ok="ok"
                @on-cancel="cancel">
            <Form ref="formValidate" :rules="ruleValidate" :model="formValidate" :label-width="90">
                <Row :gutter="16">
                    <Col span="8">
                    <FormItem label="归属公司" prop="customername">
                        <Input size="small" v-model="formValidate.customername"/>
                    </FormItem>
                    </Col>
                    <Col span="8">
                    <FormItem label="归属客户" prop="customername">
                        <Input size="small" v-model="formValidate.customername"/>
                    </FormItem>
                    </Col>
                    <Col span="8">
                    <FormItem label="缴费时间" prop="customername">
                        <DatePicker type="datetime" style="width: 200px" v-model="formValidate.date"></DatePicker>
                    </FormItem>
                    </Col>
                </Row>
                <Row :gutter="16">
                    <Col span="8">
                    <FormItem label="订单总价" prop="customername">
                        <Input size="small" v-model="formValidate.customername"/>
                    </FormItem>
                    </Col>
                    <Col span="8">
                    <FormItem label="已付款" prop="customername">
                        <Input size="small" v-model="formValidate.customername"/>
                    </FormItem>
                    </Col>
                    <Col span="8">
                    <FormItem label="缴费渠道" prop="customername">
                        <Select v-model="formValidate.customername" placeholder="Select your city">
                            <Option value="beijing">New York</Option>
                            <Option value="shanghai">London</Option>
                            <Option value="shenzhen">Sydney</Option>
                        </Select>
                    </FormItem>
                    </Col>
                </Row>
                <Row :gutter="16">
                    <Col span="8">
                    <FormItem label="不急提成总额" prop="customername">
                        <Input size="small" v-model="formValidate.customername"/>
                    </FormItem>
                    </Col>
                    <Col span="8">
                    <FormItem label="业绩" prop="customername">
                        <Input size="small" v-model="formValidate.customername"/>
                    </FormItem>
                    </Col>
                    <Col span="8">
                    <FormItem label="附加流水账" prop="customername">
                        <Input size="small" v-model="formValidate.customername"/>
                    </FormItem>
                    </Col>
                </Row>
                <Row :gutter="16">
                    <Col span="8">
                    <FormItem label="服务开始月份" prop="customername">
                        <DatePicker type="date" placeholder="Select date" style="width: 200px"></DatePicker>
                    </FormItem>
                    </Col>
                    <Col span="8">
                    <FormItem label="国地税报道" prop="customername">
                        <Select v-model="formValidate.customername" placeholder="Select your city">
                            <Option value="beijing">New York</Option>
                            <Option value="shanghai">London</Option>
                            <Option value="shenzhen">Sydney</Option>
                        </Select>
                    </FormItem>
                    </Col>
                </Row>
                <Row :gutter="16">
                    <FormItem label="选择产品" prop="customername">
                        <Button type="primary" icon="plus" @click="orderAdd = true">新增</Button>
                    </FormItem>
                </Row>
                <table id="dg" class="easyui-datagrid" title="Row Editing in DataGrid"
                       style="width:700px;height:auto"></table>
            </Form>
        </Modal>
        <Modal
                v-model="deleteOrder"
                title="请填写作废原因"
                @on-ok="ok"
                @on-cancel="cancel">
            <Input v-model="value6" type="textarea" :rows="4" placeholder="Enter something..."></Input>
        </Modal>
        <Card>
            <Row>
                <ButtonGroup>
                    <Button type="primary" icon="plus" @click="orderAdd2()">录入</Button>
                    <Button type="primary" icon="edit" @click="isEditChange">编辑</Button>
                    <Button type="primary" icon="ios-crop" @click="detailCustomer">查看</Button>
                    <Button type="primary" icon="ios-color-filter-outline">修改</Button>
                    <Button type="primary" icon="ios-color-filter-outline">企划(修改)</Button>
                    <Button type="primary" icon="ios-color-filter-outline" @click="deleteOrder = true">订单作废</Button>
                    <Button type="primary" icon="ios-color-filter-outline">导出Excel</Button>
                </ButtonGroup>
            </Row>
            <Row style="margin-top: 10px;">
                <Table border :columns="columns2" :data="data3"></Table>
            </Row>
        </Card>
    </div>
</template>

<script>
    import datagrid from '../../libs/easyUI/jquery.easyui.min'
    import combobox from '../../libs/easyUI/jquery.easyui.min'

    let editIndex = undefined;

    export default {
        data() {
            return {
                orderAdd: false,
                deleteOrder: false,
                formValidate: {
                    customername: '',
                    date: new Date()
                },
                ruleValidate: {},
                columns2: [
                    {
                        title: '订单号码',
                        key: 'age',
                        width: 120
                    },
                    {
                        title: '公司名称',
                        key: 'province',
                        width: 150
                    },
                    {
                        title: '客户名称',
                        key: 'city',
                        width: 120
                    },
                    {
                        title: '客户电话',
                        key: 'address',
                        width: 120
                    },
                    {
                        title: '流程状态',
                        key: 'zip',
                        width: 100
                    },
                    {
                        title: '缴费渠道',
                        key: 'zip',
                        width: 100
                    },
                    {
                        title: '订单价格',
                        key: 'zip',
                        width: 100
                    },
                    {
                        title: '已付款',
                        key: 'zip',
                        width: 100
                    },
                    {
                        title: '余款',
                        key: 'zip',
                        width: 100
                    },
                    {
                        title: '创建时间',
                        key: 'zip',
                        width: 100
                    },
                    {
                        title: '创建人',
                        key: 'zip',
                        width: 100
                    },
                    {
                        title: '跟进人',
                        key: 'zip',
                        width: 100
                    },
                    {
                        title: 'Action',
                        key: 'action',
                        fixed: 'right',
                        width: 120,
                        render: (h, params) => {
                            return h('div', [
                                h('Button', {
                                    props: {
                                        type: 'text',
                                        size: 'small'
                                    }
                                }, '[]'),
                                h('Button', {
                                    props: {
                                        type: 'text',
                                        size: 'small'
                                    }
                                }, 'Edit')
                            ]);
                        }
                    }
                ],
            }
        },
        methods: {
            orderAdd2() {
                let _self = this
                _self.orderAdd = true
                $(function () {
                    $('#dg').datagrid({
                        title: 'Editable DataGrid',
                        iconCls: 'icon-edit',
                        width: 660,
                        height: 250,
                        singleSelect: true,
                        idField: 'itemid',
                        method: 'get',
                        url: './datagrid_data.json',
                        columns: [[
                            {field: 'itemid', title: 'Item ID', width: 60},
                            {field: 'productid', title: 'Product', width: 100},
                            {
                                field: 'listprice',
                                title: 'List Price',
                                width: 80,
                                align: 'right',
                                editor: {type: 'numberbox', options: {precision: 1}}
                            },
                            {field: 'unitcost', title: 'Unit Cost', width: 80, align: 'right', editor: 'numberbox'},
                            {field: 'attr1', title: 'Attribute', width: 150, editor: 'textbox'},
                            {
                                field: 'status',
                                title: 'Status',
                                width: 50,
                                align: 'center',
                                editor: {type: 'checkbox', options: {on: 'P', off: ''}}
                            },
                        ]],
                        onClickRow: function (index) {
                            if (editIndex != index) {
                                function endEditing() {
                                    if (editIndex == undefined) {
                                        return true
                                    }
                                    if ($('#dg').datagrid('validateRow', editIndex)) {
                                        $('#dg').datagrid('endEdit', editIndex);
                                        editIndex = undefined;
                                        return true;
                                    } else {
                                        return false;
                                    }
                                }
                                if (endEditing()) {
                                    $('#dg').datagrid('selectRow', index)
                                        .datagrid('beginEdit', index);
                                    editIndex = index;
                                } else {
                                    $('#dg').datagrid('selectRow', editIndex);
                                }
                            }
                        },
                    });
                });
            }
        },
        mounted() {

        }
    }
</script>