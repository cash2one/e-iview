<style>
    /*@import '../../../libs/easyUI/demo.css';*/
    @import '../../../libs/easyUI/easyui.css';
    @import '../../../libs/easyUI/icon.css';
</style>
<template>
    <div>
        <Card>
            <Row style="margin-bottom: 15px">
                <ButtonGroup>
                    <Button type="primary" icon="plus" @click="addProduct = true">激活地区</Button>
                    <Button type="primary" icon="plus" @click="EditProduct = true">冻结地区</Button>
                </ButtonGroup>
            </Row>
            <table id="tg" style="width:700px;height:250px;"></table>
        </Card>
    </div>
</template>

<script>
    import treegrid from '../../../libs/easyUI/jquery.easyui.min'

    let editingId;
    export default {
        data() {
            return{
                z: '财务章'
            }
        },
        methods: {
            getTableData() {
                $('#tg').treegrid({
                    url:'./treegrid_data2.json',
                    idField:'id',
                    method:'get',
                    treeField:'name',
                    checkbox:true,
                    columns:[[
                        {title:'地区全名',field:'name',width:180,editor:'text',},
                        {field:'地区编码',title:'地区编码',width:60,align:'right',editor:'text'},
                        {field:'地区名称',title:'地区名称',width:80,editor:'text'},
                        {field:'地区状态',title:'商城价格',width:80,editor:'text'},
                        {field:'排序id',title:'后台价格',width:80,editor:'text'},
                    ]]
                });
            },
        },
        mounted() {
            this.getTableData()
        }
    }
</script>