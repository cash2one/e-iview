<style>
    /*@import '../../../libs/easyUI/demo.css';*/
    @import '../../../libs/easyUI/easyui.css';
    @import '../../../libs/easyUI/icon.css';
</style>
<template>
    <div>
        <Card>
            <Row style="margin-bottom: 15px">
                <ButtonGroup>
                    <Button type="primary" icon="plus" @click="addProduct = true">添加</Button>
                    <Button type="primary" icon="plus" @click="EditProduct = true">编辑</Button>
                    <Button type="primary" icon="plus" @click="deleteProduct = true">删除</Button>
                </ButtonGroup>
            </Row>
            <table id="tg" style="width:700px;height:250px;"></table>
        </Card>
        <Modal
                v-model="addProduct"
                title="录入"
                @on-ok="handleSubmit('formValidate')"
                @on-cancel="cancel('formValidate')">
            <Form ref="formValidate" :model="formValidate" :label-width="120">
                <FormItem label="产品类型名称" prop="productName">
                    <Input v-model="formValidate.productName" placeholder="Enter your name"></Input>
                </FormItem>
                <FormItem label="产品类型等级" prop="productName">
                    <Select v-model="formValidate.productName" style="width:200px">
                        <Option value="beijing">一级产品</Option>
                        <Option value="shanghai">下级产品</Option>
                    </Select>
                </FormItem>
                <FormItem label="顺序" prop="productName">
                    <InputNumber :max="10" :min="1" v-model="formValidate.productName"></InputNumber>
                </FormItem>
                <FormItem label="父类型" prop="productName">
                    <input class="fuleixing" style="width:200px;height: 25px"/>
                </FormItem>
            </Form>
        </Modal>
        <Modal
                v-model="EditProduct"
                title="编辑"
                @on-ok="handleSubmit('formValidate')"
                @on-cancel="cancel('formValidate')">
            <Form ref="formValidate" :model="formValidate" :label-width="120">
                <FormItem label="产品类型名称" prop="productName">
                    <Input v-model="formValidate.productName" placeholder="Enter your name"></Input>
                </FormItem>
                <FormItem label="产品类型等级" prop="productName">
                    <Select v-model="formValidate.productName" style="width:200px">
                        <Option value="beijing">一级产品</Option>
                        <Option value="shanghai">下级产品</Option>
                    </Select>
                </FormItem>
                <FormItem label="顺序" prop="productName">
                    <InputNumber :max="10" :min="1" v-model="formValidate.productName"></InputNumber>
                </FormItem>
                <FormItem label="父类型" prop="productName">
                    <input class="fuleixing" style="width:200px;height: 25px"/>
                </FormItem>
            </Form>
        </Modal>
        <Modal v-model="deleteProduct" width="360">
            <p slot="header" style="color:#f60;text-align:center">
                <Icon type="information-circled"></Icon>
                <span>删除客户</span>
            </p>
            <div style="text-align:center">
                <p>客户信息删除无法恢复</p>
                <p>确定删除吗？</p>
            </div>
            <div slot="footer">
                <Button type="error" size="large" long :loading="modal_loading" @click="deleteCustomer2">删除</Button>
            </div>
        </Modal>
    </div>
</template>

<script>
    import treegrid from '../../../libs/easyUI/jquery.easyui.min'
    import combotree from '../../../libs/easyUI/jquery.easyui.min'

    let editingId;
    export default {
        data() {
            return {
                z: '财务章',
                addProduct: false,
                EditProduct: false,
                deleteProduct: false,
                formValidate: {},
            }
        },
        methods: {
            getTableData() {
                $('#tg').treegrid({
                    url: './treegrid_data2.json',
                    idField: 'id',
                    method: 'get',
                    treeField: 'name',
                    rownumbers: true,
                    columns: [[
                        {title: '类型名称', field: 'name', width: 180, editor: 'text',},
                        {field: '类型顺序', title: '类型顺序', width: 60, align: 'right', editor: 'text'},
                    ]]
                });

                $('.fuleixing').combotree({
                    url: './tree_data1.json',
                    idField: 'id',
                    method: 'get',
                    treeField: 'name',
                    required:true,
                });
            },

            edit() {
                let _self = this

                if (_self.editingId != undefined) {
                    $('#tg').treegrid('select', _self.editingId);
                    return;
                }
                let row = $('#tg').treegrid('getSelected');
                if (row) {
                    _self.editingId = row.id
                    $('#tg').treegrid('beginEdit', _self.editingId);
                }
            },

            save() {
                let _self = this

                if (_self.editingId != undefined) {
                    var t = $('#tg');
                    t.treegrid('endEdit', _self.editingId);
                    _self.editingId = undefined;
                    var persons = 0;
                    var rows = t.treegrid('getChildren');
                    for (var i = 0; i < rows.length; i++) {
                        var p = parseInt(rows[i].persons);
                        if (!isNaN(p)) {
                            persons += p;
                        }
                    }
                    var frow = t.treegrid('getFooterRows')[0];
                    frow.persons = persons;
                    t.treegrid('reloadFooter');
                }
            },

            cancel() {
                let _self = this

                if (_self.editingId != undefined) {
                    $('#tg').treegrid('cancelEdit', _self.editingId);
                    _self.editingId = undefined;
                }
            }
        },
        mounted() {
            this.getTableData()
        }
    }
</script>