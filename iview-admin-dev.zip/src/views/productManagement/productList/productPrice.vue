<style>
    /*@import '../../../libs/easyUI/demo.css';*/
    @import '../../../libs/easyUI/easyui.css';
    @import '../../../libs/easyUI/icon.css';
</style>
<template>
    <div>
        <Card>
            <RadioGroup v-model="z" style="margin-bottom: 15px">
                <Radio label="财务章"></Radio>
                <Radio label="法人章"></Radio>
                <Radio label="公章"></Radio>
                <Radio label="发票章"></Radio>
                <Radio label="合同章"></Radio>
            </RadioGroup>
            <table id="tg" style="width:700px;height:250px;"></table>
        </Card>
<!--        <div style="margin:20px 0;">
            <Button @click.native="edit()">Edit</Button>
            <Button @click.native="save()">save</Button>
            <Button @click.native="cancel()">cancel</Button>
        </div>-->
    </div>
</template>

<script>
    import treegrid from '../../../libs/easyUI/jquery.easyui.min'

    let editingId;
    export default {
        data() {
            return{
                z: '财务章'
            }
        },
        methods: {
            getTableData() {
                $('#tg').treegrid({
                    url:'./treegrid_data2.json',
                    idField:'id',
                    method:'get',
                    treeField:'name',
                    checkbox:true,
                    columns:[[
                        {title:'地区全名',field:'name',width:180,editor:'text',},
                        {field:'地区编码',title:'地区编码',width:60,align:'right',editor:'text'},
                        {field:'地区名称',title:'地区名称',width:80,editor:'text'},
                        {field:'商城价格',title:'商城价格',width:80,editor:'text'},
                        {field:'后台价格',title:'后台价格',width:80,editor:'text'},
                        {field:'状态',title:'状态',width:80,editor:'text'},
                    ]]
                });
            },

            edit() {
                let _self = this

                if (_self.editingId != undefined){
                    $('#tg').treegrid('select', _self.editingId);
                    return;
                }
                let row = $('#tg').treegrid('getSelected');
                if (row){
                    _self.editingId = row.id
                    $('#tg').treegrid('beginEdit', _self.editingId);
                }
            },

            save() {
                let _self = this

                if (_self.editingId != undefined){
                    var t = $('#tg');
                    t.treegrid('endEdit', _self.editingId);
                    _self.editingId = undefined;
                    var persons = 0;
                    var rows = t.treegrid('getChildren');
                    for(var i=0; i<rows.length; i++){
                        var p = parseInt(rows[i].persons);
                        if (!isNaN(p)){
                            persons += p;
                        }
                    }
                    var frow = t.treegrid('getFooterRows')[0];
                    frow.persons = persons;
                    t.treegrid('reloadFooter');
                }
            },

            cancel() {
                let _self = this

                if (_self.editingId != undefined){
                    $('#tg').treegrid('cancelEdit', _self.editingId);
                    _self.editingId = undefined;
                }
            }
        },
        mounted() {
            this.getTableData()
        }
    }
</script>