<style lang="less">
    @import '../../../styles/common.less';
    @import '../../my-components/markdown-editor/markdown-editor.less';
</style>
<style>
    @import '../../../libs/easyUI/easyui.css';
    @import '../../../libs/easyUI/icon.css';
</style>
<style>
    .CodeMirror{
        min-height: 305px !important;
    }
</style>

<template>
    <div>
        <Card>
            <Row>
                <ButtonGroup>
                    <Button type="primary" icon="plus" @click="addProduct = true">录入</Button>
                    <Button type="primary" icon="plus" @click="EditProduct = true">编辑</Button>
                    <Button type="primary" icon="plus" @click="detailProduct = true">查看</Button>
                </ButtonGroup>
            </Row>
            <Row style="margin-top: 10px;">
                <Table
                        highlight-row
                        size="small"
                        :columns="columns"
                        :data="data"
                        @on-current-change="selectRow"></Table>
                <Page
                        size="small"
                        :total="pageTotal"
                        show-total
                        show-sizer
                        show-elevator
                        @on-change="pageChange"
                        @on-page-size-change="pageSizeChange"
                        style="margin-top: 10px"></Page>
            </Row>
        </Card>
        <Modal
                v-model="addProduct"
                title="录入"
                @on-ok="handleSubmit('formValidate')"
                @on-cancel="cancel('formValidate')">
            <Tabs value="name1">
                <TabPane label="基本信息" name="name1">
                    <Form ref="formValidate" :model="formValidate" :label-width="120">
                        <FormItem label="产品名称" prop="productName">
                            <Input v-model="formValidate.productName" placeholder="Enter your name"></Input>
                        </FormItem>
                        <FormItem label="产品类型" prop="productName">
                            <input class="chanpin" style="width:200px;height: 25px"/>
                        </FormItem>
                        <FormItem label="是否为周期性产品" prop="productName">
                            <Select v-model="formValidate.productName" placeholder="Select your city">
                                <Option value="beijing">是</Option>
                                <Option value="shanghai">否</Option>
                            </Select>
                        </FormItem>
                        <FormItem label="默认服务部门" prop="productName">
                            <Select v-model="formValidate.productName" placeholder="Select your city">
                                <Option value="beijing">是</Option>
                                <Option value="shanghai">否</Option>
                            </Select>
                        </FormItem>
                        <FormItem label="服务部门" prop="productName">
                            <CheckboxGroup v-model="formValidate.productName">
                                <Checkbox label="Eat">市场部</Checkbox>
                                <Checkbox label="Sleep">企划部</Checkbox>
                                <Checkbox label="Run">会计部</Checkbox>
                                <Checkbox label="Movie">商事部</Checkbox>
                                <Checkbox label="Movie">行政部</Checkbox>
                                <Checkbox label="Movie">财务部</Checkbox>
                                <Checkbox label="Movie">人事部</Checkbox>
                                <Checkbox label="Movie">研发部</Checkbox>
                                <Checkbox label="Movie">审计部</Checkbox>
                                <Checkbox label="Movie">兼职会计部</Checkbox>
                            </CheckboxGroup>
                        </FormItem>
                        <FormItem label="产品编码" prop="productName">
                            <Input v-model="formValidate.productName" placeholder="Enter your name"></Input>
                        </FormItem>
                        <FormItem label="产品属性">
                            <Button @click="add = true">选择</Button>
                        </FormItem>
                    </Form>
                </TabPane>
                <TabPane label="产品详情" name="name2">
                    <textarea id="iview_admin_markdown_editor" style="display:none"></textarea>
                </TabPane>
            </Tabs>
        </Modal>
        <Modal
                v-model="EditProduct"
                title="编辑"
                @on-ok="handleSubmit('formValidate')"
                @on-cancel="cancel('formValidate')">
            <Tabs value="name1">
                <TabPane label="基本信息" name="name1">
                    <Form ref="formValidate" :model="formValidate" :label-width="120">
                        <FormItem label="产品名称" prop="productName">
                            <Input v-model="formValidate.productName" placeholder="Enter your name"></Input>
                        </FormItem>
                        <FormItem label="产品类型" prop="productName">
                            <input class="chanpin" style="width:200px;height: 25px"/>
                        </FormItem>
                        <FormItem label="是否为周期性产品" prop="productName">
                            <Select v-model="formValidate.productName" placeholder="Select your city">
                                <Option value="beijing">是</Option>
                                <Option value="shanghai">否</Option>
                            </Select>
                        </FormItem>
                        <FormItem label="默认服务部门" prop="productName">
                            <Select v-model="formValidate.productName" placeholder="Select your city">
                                <Option value="beijing">是</Option>
                                <Option value="shanghai">否</Option>
                            </Select>
                        </FormItem>
                        <FormItem label="服务部门" prop="productName">
                            <CheckboxGroup v-model="formValidate.productName">
                                <Checkbox label="Eat">市场部</Checkbox>
                                <Checkbox label="Sleep">企划部</Checkbox>
                                <Checkbox label="Run">会计部</Checkbox>
                                <Checkbox label="Movie">商事部</Checkbox>
                                <Checkbox label="Movie">行政部</Checkbox>
                                <Checkbox label="Movie">财务部</Checkbox>
                                <Checkbox label="Movie">人事部</Checkbox>
                                <Checkbox label="Movie">研发部</Checkbox>
                                <Checkbox label="Movie">审计部</Checkbox>
                                <Checkbox label="Movie">兼职会计部</Checkbox>
                            </CheckboxGroup>
                        </FormItem>
                        <FormItem label="产品编码" prop="productName">
                            <Input v-model="formValidate.productName" placeholder="Enter your name"></Input>
                        </FormItem>
                        <FormItem label="产品属性">
                            <Button @click="add = true">选择</Button>
                        </FormItem>
                    </Form>
                </TabPane>
                <TabPane label="产品详情" name="name2">
                    <textarea  id="iview_admin_markdown_editor2" style="display:none"></textarea>
                </TabPane>
            </Tabs>
        </Modal>
        <Modal
                v-model="detailProduct"
                title="查看"
                @on-ok="handleSubmit('formValidate')"
                @on-cancel="cancel('formValidate')">
            <Tabs value="name1">
                <TabPane label="基本信息" name="name1">
                    <Form ref="formValidate" :model="formValidate" :label-width="120">
                        <FormItem label="产品名称" prop="productName">
                            <Input v-model="formValidate.productName" placeholder="Enter your name"></Input>
                        </FormItem>
                        <FormItem label="产品类型" prop="productName">
                            <input class="chanpin" style="width:200px;height: 25px"/>
                        </FormItem>
                        <FormItem label="是否为周期性产品" prop="productName">
                            <Select v-model="formValidate.productName" placeholder="Select your city">
                                <Option value="beijing">是</Option>
                                <Option value="shanghai">否</Option>
                            </Select>
                        </FormItem>
                        <FormItem label="默认服务部门" prop="productName">
                            <Select v-model="formValidate.productName" placeholder="Select your city">
                                <Option value="beijing">是</Option>
                                <Option value="shanghai">否</Option>
                            </Select>
                        </FormItem>
                        <FormItem label="服务部门" prop="productName">
                            <CheckboxGroup v-model="formValidate.productName">
                                <Checkbox label="Eat">市场部</Checkbox>
                                <Checkbox label="Sleep">企划部</Checkbox>
                                <Checkbox label="Run">会计部</Checkbox>
                                <Checkbox label="Movie">商事部</Checkbox>
                                <Checkbox label="Movie">行政部</Checkbox>
                                <Checkbox label="Movie">财务部</Checkbox>
                                <Checkbox label="Movie">人事部</Checkbox>
                                <Checkbox label="Movie">研发部</Checkbox>
                                <Checkbox label="Movie">审计部</Checkbox>
                                <Checkbox label="Movie">兼职会计部</Checkbox>
                            </CheckboxGroup>
                        </FormItem>
                        <FormItem label="产品编码" prop="productName">
                            <Input v-model="formValidate.productName" placeholder="Enter your name"></Input>
                        </FormItem>
                        <FormItem label="产品属性">
                            <Button @click="add = true">选择</Button>
                        </FormItem>
                    </Form>
                </TabPane>
                <TabPane label="产品详情" name="name2">
                    <textarea  id="iview_admin_markdown_editor3" style="display:none"></textarea>
                </TabPane>
            </Tabs>
        </Modal>
        <Modal
                v-model="add"
                title="录入">
            <Button type="primary" icon="plus" @click="">添加</Button>
            <Table border ref="selection" :columns="columns4" :data="data11"></Table>
        </Modal>
    </div>
</template>

<script>
    import SimpleMDE from 'simplemde';
    import '../../my-components/markdown-editor/simplemde.min.css';
    import combotree from '../../../libs/easyUI/jquery.easyui.min'

    export default {
        data() {
            return {
                add: false,
                addProduct: false,
                EditProduct: false,
                detailProduct: false,
                formValidate: {
                    productName: '',
                },
                pageTotal: '',
                customerid: '',
                data: [],
                areaValue: [],
                customertypeValue: [],
                importlevelValue: [],
                columns4: [
                    {
                        type: 'selection',
                        width: 60,
                        align: 'center'
                    },
                    {
                        title: '分类',
                        key: 'name'
                    },
                    {
                        title: '属性名称',
                        key: 'age'
                    }
                ],
                columns: [
                    {
                        title: '产品名称',
                        key: 'product',
                    },
/*                    {
                        title: '产品类型',
                        key: 'customer_status',
                    },*/
                    {
                        title: '状态',
                        key: 'status',
                    },
                    {
                        title: '产品编码',
                        key: 'productcode',
                    },
                    {
                        title: '操作',
                        key: 'action',
                        align: 'center',
                        render: (h, params) => {
                            return h('div', [
                                h('Button', {
                                    props: {
                                        type: 'text',
                                        size: 'small'
                                    },
                                    style: {
                                        marginRight: '5px'
                                    },
                                    on: {
                                        click: () => {
                                            this.examine(params)
                                        }
                                    }
                                }, '删除'),
                                h('Button', {
                                    props: {
                                        type: 'text',
                                        size: 'small'
                                    },
                                    style: {
                                        marginRight: '5px'
                                    },
                                    on: {
                                        click: () => {
                                            this.$router.push({
                                                name: 'productPrice'
                                            });
                                        }
                                    }
                                }, '编辑价格'),
                                h('Button', {
                                    props: {
                                        type: 'text',
                                        size: 'small'
                                    },
                                    style: {
                                        marginRight: '5px'
                                    },
                                    on: {
                                        click: () => {
                                            sessionStorage.setItem('productId', params.row.id)
                                            this.$router.push({
                                                name: 'productAttribute'
                                            });
                                        }
                                    }
                                }, '选择产品'),
                            ]);
                        }
                    }
                ],
                data1: [
                    {
                        title: 'parent 1',
                        expand: true,
                        children: [
                            {
                                title: 'parent 1-1',
                                expand: true,
                                children: [
                                    {
                                        title: 'leaf 1-1-1'
                                    },
                                    {
                                        title: 'leaf 1-1-2'
                                    }
                                ]
                            },
                            {
                                title: 'parent 1-2',
                                expand: true,
                                children: [
                                    {
                                        title: 'leaf 1-2-1'
                                    },
                                    {
                                        title: 'leaf 1-2-1'
                                    }
                                ]
                            }
                        ]
                    }
                ]
            }
        },
        methods: {
            getData() {
                $('.chanpin').combotree({
                    url: './tree_data1.json',
                    idField: 'id',
                    method: 'get',
                    treeField: 'name',
                    required:true,
                });

                let _self = this
               /* let url = '/baseProductController.do?datagrid&field=id,product,producttype.typename,status,productcode,'

                function doSuccess(response) {
                    let _data = response.data.data
                    console.log(response)

//                    _self.searchTypegroup('customerType')
                    _self.pageTotal = response.data.data.total

                    for (let i = 0; i < _data.rows.length; i++) {
                        /!*   let _customerTypeArr = JSON.parse(localStorage.getItem('customerType'))
                           for (let j = 0; j < _customerTypeArr.length; j++) {
                               if (_data.rows[i].customer_status == _customerTypeArr[j].) {

                               }
                           }*!/
                        _self.data.push({
                            cluestatus: _data.rows[i].cluestatus,
                            followbyname: _data.rows[i].followbyname,
                            customer_name: _data.rows[i].customer_name,
                            channel_name: _data.rows[i].channel_name,
                            createdate: _data.rows[i].createdate,
                            customer_area: _data.rows[i].customer_area,
                            customer_email: _data.rows[i].customer_email,
                            customer_level: _data.rows[i].customer_level,
                            customer_memo: _data.rows[i].customer_memo,
                            customer_status: _data.rows[i].customer_status,
                            customer_tags: _data.rows[i].customer_tags,
                            customer_id: _data.rows[i].customer_id,
                            updatedate: _data.rows[i].updatedate,
                            createby: _data.rows[i].createby,
                            people: [
                                {
                                    customer_mobile_phone: _data.rows[i].customer_mobile_phone,
                                    customer_tel: _data.rows[i].customer_tel,
                                    customer_wechat: _data.rows[i].customer_wechat,
                                    customerqq: _data.rows[i].customerqq,
                                }
                            ]
                        })
                    }
                }

                this.GetData(url, doSuccess)*/

               this.$http.get('./productData.json')
                   .then(function (response) {
                       for (let i = 0; i < response.data.rows.length; i++) {
                           _self.data.push({
                               id: response.data.rows[i].id,
                               product: response.data.rows[i].product,
                               productcode: response.data.rows[i].productcode,
                               status: response.data.rows[i].status,
                           })
                       }
                   })
            },
            examine(e) {
                this.$emit('isExamine', e.row.customer_id)
            },
            // 表格行选中事件
            selectRow(a) {
                var _self = this
                _self.customerid = a.customer_id
            },
            handleSubmit(name) {
                let _self = this
                this.$refs[name].validate((valid) => {
                    if (valid) {
                        let _customertypeStr = _self.formValidate.customerStatus[1]
                        _self.formValidate.customerStatus = _customertypeStr
                        if ((_self.formValidate.customerTel == '' || _self.formValidate.customerTel == null) && (_self.formValidate.customerMobilePhone == '' || _self.formValidate.customerMobilePhone == null) && (_self.formValidate.customerWechat == '' || _self.formValidate.customerWechat == null) && (_self.formValidate.customerQQ == '' || _self.formValidate.weixin == null)) {
                            this.$nextTick(() => {
                                this.loading = true;
                            });
                            this.$Message.error('电话、固话、QQ、微信必须填写一个');
                        } else {
                            this.$http({
                                method: 'post',
                                url: '/api/channel/customer/channel/create',
                                data: _self.formValidate,
                            })
                                .then(function (response) {
                                    if (response.data.msgCode == '40000') {
                                        _self.$Message.success('新增成功!')
                                        _self.getData()
                                    }
                                })
                        }
                    } else {
                        this.$Message.error('新增失败!');
                        _self.cancel('formValidate')
                    }
                })
            },
            cancel(name) {
                this.$refs[name].resetFields();
            },
            downloadExcel() {
                let url = '/channel/customer/channel/1/9999999/list'
                let _objdata = {}
                let _response = JSON.parse(localStorage.getItem('area'))

                this.searchTypegroup('area')

                for(let i = 0; i < _response.length; i++) {
                    _objdata[_response[i].typecode] = _response[i].typename
                }

                let arrdata = [
                    {
                        field: 'customer_name',title: '客户名称'
                    },
                    {
                        field: 'customer_mobile_phone',title: '客户手机号'
                    },
                    {
                        field: 'followbyname',title: '跟进人'
                    },
                    {
                        field:'customer_area',title:'客户区域',format: _objdata
                    }
                ]

                this.DownloadExcel(url, JSON.stringify(arrdata))
            }
        },
        mounted() {
            this.getData()
            new SimpleMDE({
                element: document.getElementById('iview_admin_markdown_editor'),
                toolbar: ['bold', 'italic', 'strikethrough', 'heading', 'heading-smaller', 'heading-bigger', 'heading-1', 'heading-2', 'heading-3', '|', 'code', 'quote', 'unordered-list', 'clean-block', '|', 'link', 'image', 'table', 'horizontal-rule', '|', 'preview', 'guide']
            });
            new SimpleMDE({
                element: document.getElementById('iview_admin_markdown_editor2'),
                toolbar: ['bold', 'italic', 'strikethrough', 'heading', 'heading-smaller', 'heading-bigger', 'heading-1', 'heading-2', 'heading-3', '|', 'code', 'quote', 'unordered-list', 'clean-block', '|', 'link', 'image', 'table', 'horizontal-rule', '|', 'preview', 'guide']
            });
            new SimpleMDE({
                element: document.getElementById('iview_admin_markdown_editor3'),
                toolbar: ['bold', 'italic', 'strikethrough', 'heading', 'heading-smaller', 'heading-bigger', 'heading-1', 'heading-2', 'heading-3', '|', 'code', 'quote', 'unordered-list', 'clean-block', '|', 'link', 'image', 'table', 'horizontal-rule', '|', 'preview', 'guide']
            });
        }
    }
</script>