<style>
    @import './css/productDetail.min.css';
</style>
<template>
    <div>
        <div class="productDetail-title">
            <p id="product_name"></p>
            <p class="productDetail-title-price">
                <span>￥<strong id="product_price">加载中</strong></span>
            </p>
            <div class="productDetail-title-content">
            </div>
        </div>
        <div class="productDetail-option" id="productDetail-option-id" onclick="selectClose()">
            <p id="areaId">地区</p>
            <div class="productDetail-option-chooseArea">
                <input id="chooseArea" type="text" readonly="readonly" placeholder="请选择地区" autocomplete="off" onfocus="this.blur();"/>
                <input id="chooseAreaValue" type="hidden" value="20,234,504"/>
            </div>
        </div>
        <div class="productDetail-footer">
            <input id="areaPropertyId" type="hidden"/>
            <div class="tel">
                <a href="#" class="button" onclick="addOrder()">下单</a>
            </div>
        </div>
    </div>
</template>

<script>

    export default {
        methods: {
            getData() {
                this.$http({
                    method: 'POST',
                    url: '/api/baseProductController.do?getSKUListByProductId',
                    data: {
                        productId: sessionStorage.getItem('productId')
                    },
                    headers: {'Content-Type': 'application/json'},
                })
                    .then(function (response) {
                        console.log(response)
                    })
            }
        },
        mounted() {
            this.getData()
        }
    }
</script>