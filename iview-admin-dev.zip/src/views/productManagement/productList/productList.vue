<template>
    <div>
        <product-table></product-table>
    </div>
</template>

<script>
    import productTable from './product_table.vue'

    export default {
        components: {
            productTable
        }
    }
</script>