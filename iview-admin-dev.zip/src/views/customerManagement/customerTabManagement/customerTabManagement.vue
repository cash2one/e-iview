<template>
    <div>
        <index-table></index-table>
    </div>
</template>

<script>
    import indexTable from './customerTabManagement_table.vue'

    export default {
        components: {
            indexTable
        },
        data() {
            return {}
        },
    }
</script>